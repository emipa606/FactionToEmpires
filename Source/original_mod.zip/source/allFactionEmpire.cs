﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using Verse;
using RimWorld;
using UnityEngine;
using HugsLib;
using HugsLib.Settings;



namespace empireMaker
{

    public class empireMaker : ModBase
	{
        
        public override string ModIdentifier => "empireMaker";

        private SettingHandle<bool> phychicAllSetting;
        public static bool phychicAll = true;

        private SettingHandle<bool> delVanillaSetting;
        public static bool delVanilla = false;

        private SettingHandle<float> questAmountSetting;
        public static float questAmount = 1f;

        private SettingHandle<bool> debugModeSetting;
        public static bool debugMode = false;

        static public List<FactionDef> ar_faction = new List<FactionDef>();
        static public List<en_make> ar_faction_toEmpire = new List<en_make>();
        static public List<SettingHandle<en_relation>> ar_faction_relationSetting = new List<SettingHandle<en_relation>>();
        static public List<en_relation> ar_faction_relation = new List<en_relation>();
        static public List<en_apparel> ar_faction_Apparel = new List<en_apparel>();
        static public List<bool> ar_faction_collector = new List<bool>();
        static public List<bool> ar_faction_tradePermit = new List<bool>();
        static public List<FactionDef> ar_faction_willEmpire = new List<FactionDef>();

        public enum en_make { no, empire, bugFix }

        public enum en_apparel { off, forced, basic }

        public enum en_relation { basic, empire, ally, neutral, enemy, permanentEnemy }


        // 비호환 하드모드 패키지 아이디
        static public List<string> ar_hardModPkg = new List<string>() { "projectjedi.factions", "kikohi.forsakens" };

        public override void DefsLoaded()
		{
            

            //Setup and get settings values
            foreach (FactionDef faction in from faction in DefDatabase<FactionDef>.AllDefs where
                faction.royalFavorLabel == null &&
                !faction.hidden &&
                //(faction.naturalColonyGoodwill.min >= 0 || faction.naturalColonyGoodwill.max >= 0) &&
                !faction.mustStartOneEnemy &&
                //!faction.permanentEnemy &&
                faction.pawnGroupMakers != null &&
                !faction.isPlayer
            select faction
            )
            {
                ar_faction.Add(faction);
            }


            // 초능력 공용화
            phychicAllSetting = Settings.GetHandle<bool>($"phychicAll", $"phychicAll_t".Translate(), "phychicAll_d".Translate(), true);
            phychicAll = phychicAllSetting.Value;

            // 바닐라 제국 숨기기
            delVanillaSetting = Settings.GetHandle<bool>($"delVanilla", $"delVanilla_t".Translate(), "delVanilla_d".Translate(), false);
            delVanillaSetting.NeverVisible = true;
            delVanilla = delVanillaSetting.Value;

            // 퀘스트 생성량
            questAmountSetting = Settings.GetHandle<float>($"questAmount", $"questAmount_t".Translate(), "questAmount_d".Translate(), 1f);
            questAmountSetting.NeverVisible = true;
            questAmount = questAmountSetting.Value;

            for (int i = 0; i < ar_faction.Count; i++)
            {
                // 옵션 관리
                FactionDef f = ar_faction[i];
                bool isHardMod = ar_hardModPkg.Contains(f.modContentPack.PackageId);


                // 제국화
                if(f.permanentEnemy)
                {
                    ar_faction_toEmpire.Add(Settings.GetHandle<en_make>($"{f.defName}ToEmpire", $"==== {f.label.ToUpper()} ====", "make_d".Translate(), en_make.no, null, "en_make_").Value);
                }
                else if (!isHardMod) 
                {
                    ar_faction_toEmpire.Add(Settings.GetHandle<en_make>($"{f.defName}ToEmpire", $"==== {f.label.ToUpper()} ====", "make_d".Translate(), en_make.empire, null, "en_make_").Value);
                }
                else
                {
                    // 이 모드가 하드모드 일경우에 bugFix로 설정
                    en_make tmp = Settings.GetHandle<en_make>($"{f.defName}ToEmpire", $"==== {f.label.ToUpper()} ====", "make_d".Translate(), en_make.bugFix, null, "en_make_").Value;
                    if (tmp == en_make.empire) tmp = en_make.bugFix;
                    ar_faction_toEmpire.Add(tmp);
                }

                // 관계
                ar_faction_relationSetting.Add(Settings.GetHandle<en_relation>($"{f.defName}Relation", $"relation_t".Translate(), "relation_d".Translate(), en_relation.basic, null, "en_relation_"));
                ar_faction_relation.Add(ar_faction_relationSetting[i].Value);
                //ar_faction_relation.Add(Settings.GetHandle<en_relation>($"{f.defName}Relation", $"relation_t".Translate(), "relation_d".Translate(), en_relation.basic, null, "en_relation_").Value);


                // 왕족 의상
                ar_faction_Apparel.Add(Settings.GetHandle<en_apparel>($"{f.defName}Apparel", "apparel_t".Translate(), "apparel_d".Translate(), en_apparel.basic, null, "en_apparel_").Value);
                

                // 거래제한과 권한
                ar_faction_tradePermit.Add(Settings.GetHandle<bool>($"{f.defName}TradePermit", $"trade_t".Translate(), "trade_d".Translate(), false).Value);
                
                // 공물 징수원
                //ar_faction_collector.Add(Settings.GetHandle<bool>($"{f.defName}Collector", $"     - (not developed yet)use tribute collector", "A caravan trader selling royal favors.\n\n* Need to restart and new game", true).Value);
            }

            // 디버그 모드
            debugModeSetting = Settings.GetHandle<bool>($"debugMode", $"debugMode_t".Translate(), "debugMode_d".Translate(), false);
            debugMode = debugModeSetting.Value;


            patchDef();
		}


        public override void SettingsChanged()
        {
            phychicAll = phychicAllSetting.Value;
            delVanilla = delVanillaSetting.Value;

            if (questAmountSetting.Value < 0.1f)
            {
                questAmountSetting.Value = 0.1f;
            }
            else if(questAmountSetting.Value > 20f)
            {
                questAmountSetting.Value = 20f;
            }
            questAmount = questAmountSetting.Value;

            debugMode = debugModeSetting.Value;
            for(int i = 0; i < ar_faction_relation.Count; i++)
            {
                ar_faction_relation[i] = ar_faction_relationSetting[i].Value;
            }
        }

        public static void patchDef()
		{
            Log.Message($"## Empire Maker Start Install");

            /*
            // 스토리텔러 퀘스트 양 조절
            foreach (StorytellerDef s in from st in DefDatabase<StorytellerDef>.AllDefs
                                        where
                                        st.comps != null
                                        select st)
            {
                foreach (StorytellerCompProperties c in from comp in s.comps
                                             where
                                             comp.GetType() == typeof(StorytellerCompProperties_RandomQuest)
                                             select comp)
                {
                    Log.Message("ssssssssss");
                    ((StorytellerCompProperties_RandomQuest)c).onDays = 0.2f;
                    ((StorytellerCompProperties_RandomQuest)c).numIncidentsRange = FloatRange.FromString("5~10");
                    c.minDaysPassed = 0.2f;
                    c.minIncChancePopulationIntentFactor = 1f;
                }
            }
            */

            // 제국
            FactionDef baseF = FactionDefOf.Empire;

            // 제국 타이틀
            List<RoyalTitleDef> ar_baseT = new List<RoyalTitleDef>();

            foreach (RoyalTitleDef t in from title in DefDatabase<RoyalTitleDef>.AllDefs
                                           where
                                           title.tags.Contains("EmpireTitle")
                                           select title
                                           )
            {
                ar_baseT.Add(t);
            }
            ar_baseT.OrderBy(t => t.favorCost);


            // 제국 폰 리스트
            List<PawnKindDef> ar_baseP = new List<PawnKindDef>();
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Yeoman"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Esquire"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Knight"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Praetor"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Baron"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Count"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Duke"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Consul"));
            ar_baseP.Add(PawnKindDef.Named("Empire_Royal_Stellarch"));



            for (int z = 0; z < ar_faction.Count; z++)
            {
                FactionDef faction = ar_faction[z];

                if (ar_faction_toEmpire[z] != en_make.no)
                {
                    Log.Message($"# make to empire : {ar_faction[z].defName} ({ar_faction[z].modContentPack.PackageId})");
                }
                else
                {
                    Log.Message($"# not make to empire : {ar_faction[z].defName} ({ar_faction[z].modContentPack.PackageId})");
                }
                    
                if (ar_faction_toEmpire[z] != en_make.no)
                {

                    en_apparel useApparel = ar_faction_Apparel[z];
                    
                    if (!faction.humanlikeFaction) useApparel = en_apparel.off;

                    bool bugFixMode = (ar_faction_toEmpire[z] == en_make.bugFix);
                    //bool useCollectorTrader = ar_faction_collector[z];
                    bool useTradePermit = ar_faction_tradePermit[z];

                    List<PawnKindDef> ar_permitPawn = new List<PawnKindDef>();
                    List<PawnKindDef> allPawn = new List<PawnKindDef>();
                    List<PawnKindDef> allPawnNoLeader = new List<PawnKindDef>();
                    List<PawnKindDef> allFighterPawn = new List<PawnKindDef>();
                    List<PawnKindDef> allPawnLeader = new List<PawnKindDef>();



                    if (debugMode) Log.Message("A");


                    // 팩션 제국화
                    faction.royalFavorLabel = baseF.royalFavorLabel;

                    faction.royalTitleInheritanceRelations = baseF.royalTitleInheritanceRelations;
                    faction.royalTitleInheritanceWorkerClass = baseF.royalTitleInheritanceWorkerClass;
                    faction.minTitleForBladelinkWeapons = baseF.minTitleForBladelinkWeapons;
                    string customTitleTag = $"{faction.defName}Title";
                    faction.royalTitleTags = new List<string>() { customTitleTag };


                    

                    // 히든 세력일 경우
                    /*
                    if(faction.hidden != null && faction.hidden)
                    {
                        faction.hidden = false;
                        faction.settlementGenerationWeight = 0f;
                        if(faction.leaderTitle == null || faction.leaderTitle == "") // 리더 정보가 없을경우
                        {
                            //faction.fixedLeaderKinds = new List<PawnKindDef>() { PawnKindDef.Named("Mech_Centipede") };

                            
                            
                            PawnKindDef newPawn = copyPawnDef(PawnKindDef.Named("Empire_Royal_Stellarch"));
                            newPawn.defName = $"{faction.label}_leader";
                            newPawn.defaultFactionType = faction;

                            DefDatabase<PawnKindDef>.Add(newPawn);
                            allPawn.Add(newPawn);

                            faction.fixedLeaderKinds = new List<PawnKindDef>() { newPawn };


                            if (!faction.humanlikeFaction) // 인간형 팩션이 아닐경우
                            {
                                faction.humanlikeFaction = true;
                                faction.hairTags = baseF.hairTags;
                                faction.backstoryFilters = baseF.backstoryFilters;
                                faction.pawnNameMaker = baseF.pawnNameMaker;

                                faction.autoFlee = true;

                            }
                        }

                        faction.leaderTitle = $"{faction.label} leader";
                        faction.leaderTitleFemale = faction.leaderTitle;
                        faction.canMakeRandomly = true;
                        faction.settlementNameMaker = baseF.settlementNameMaker;

                        faction.leaderForceGenerateNewPawn = true;

                    }
                    */
                    
                        


                    //
                    /*
                    faction.pawnSingular = "A";
                    faction.categoryTag = faction.defName;
                    faction.listOrderPriority = 100;

                    faction.leaderForceGenerateNewPawn = true;
                    faction.geneticVariance = 0.8f;
                    faction.renounceTitleMessage = baseF.renounceTitleMessage;
                    */
                    //faction.fixedLeaderKinds = new List<PawnKindDef>() { faction.pawnGroupMakers[0].options[0].kind };
                    if (faction.colorSpectrum == null) faction.colorSpectrum = new List<Color>() { Color.white };


                    //

                    

                    if (debugMode) Log.Message("B");


                    // 이 팩션의  모든 폰 리스트
                    /*
                    // defaultFactionType 비교방식
                    foreach (PawnKindDef pawn in from pawn in DefDatabase<PawnKindDef>.AllDefs where 
                                                 pawn.defaultFactionType != null
                                                 && pawn.defaultFactionType == faction
                                                 //&& pawn.isFighter != null
                                                 //&& pawn.isFighter
                                                 select pawn)
                    {
                        allPawn.Add(pawn);
                    }
                    */
                    //
                    foreach(PawnGroupMaker g in faction.pawnGroupMakers)
                    {
                        if (debugMode) Log.Message(g.options.Count.ToString());
                        for (int i = 0; i < g.options.Count; i++)
                        {
                            if (debugMode) Log.Message("b");
                            PawnKindDef p = g.options[i].kind;
                            if (!allPawn.Contains(p))
                            {
                                if (debugMode) Log.Message($" - {faction.defName} : pawnkind : {p.defName}");
                                allPawn.Add(p);
                                if (p.factionLeader != null && p.factionLeader)
                                {
                                    allPawnLeader.Add(p);
                                }
                                else
                                {
                                    allPawnNoLeader.Add(p);
                                }
                            }
                            
                        }
                    }

                    allPawn = allPawn.OrderBy(a => a.combatPower).ToList();
                    if (allPawnNoLeader.Count <= 0) allPawnNoLeader = allPawn;
                    allPawnNoLeader = allPawnNoLeader.OrderBy(a => a.combatPower).ToList();
                    allPawnLeader = allPawnLeader.OrderBy(a => a.combatPower).ToList();
                    Log.Message($" - {faction.defName} : total pawn count : {allPawn.Count}, leader count : {allPawnLeader.Count}");



                    if (debugMode) Log.Message("B1");



                    // fighter pawn 리스트
                    foreach (PawnKindDef pawn in from pawn in allPawn
                                                 where
                                                 pawn.isFighter != null
                                                 && pawn.isFighter
                                                 select pawn)
                    {
                        allFighterPawn.Add(pawn);
                    }
                    allFighterPawn = allFighterPawn.OrderBy(a => a.combatPower).ToList();
                    

                    if (allFighterPawn.Count == 0)
                    {
                        allFighterPawn = allPawn;
                        Log.Message($" - {faction.defName} : total fighter pawn count : {allFighterPawn.Count}, change to use allPawn");
                    }
                    else
                    {
                        Log.Message($" - {faction.defName} : total fighter pawn count : {allFighterPawn.Count}");
                    }



                    // 폰카인드 없음 스킵
                    if (allPawn.Count == 0) Log.Error($" - {faction.defName} : Can not read any pawnkind, Turn off the 'make empire' for this faction in the 'faction to empire mod' option.\nTurn off the 'make empire' for this faction in the 'faction to empire mod' option.\nAnd let the author know that this mod is not compatible.");



                    if (debugMode) Log.Message("B2");



                    // 호위병 소환을 위한 폰 등록

                    if (allFighterPawn.Count == 0)
                    {
                        ar_permitPawn.Add(PawnKindDef.Named("Empire_Fighter_Trooper"));
                        ar_permitPawn.Add(PawnKindDef.Named("Empire_Fighter_Janissary"));
                        ar_permitPawn.Add(PawnKindDef.Named("Empire_Fighter_Cataphract"));
                    }
                    else if (allFighterPawn.Count <= 3)
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            ar_permitPawn.Add(allFighterPawn[Mathf.Clamp(i, 0, allFighterPawn.Count - 1)]);
                        }
                    }
                    else
                    {
                        ar_permitPawn.Add(allFighterPawn[0]);
                        ar_permitPawn.Add(allFighterPawn[Mathf.RoundToInt((float)(allFighterPawn.Count - 1) * 0.5f)]);
                        ar_permitPawn.Add(allFighterPawn[allFighterPawn.Count - 1]);
                    }

                    if (debugMode) Log.Message("C");


                    // 커스텀 권한 생성

                    RoyalTitlePermitDef p_TradeSettlement = new RoyalTitlePermitDef();
                    RoyalTitlePermitDef p_TradeOrbital = new RoyalTitlePermitDef();
                    RoyalTitlePermitDef p_TradeCaravan = new RoyalTitlePermitDef();

                    RoyalTitlePermitDef CallMilitaryAidSmall = new RoyalTitlePermitDef();
                    RoyalTitlePermitDef CallMilitaryAidLarge = new RoyalTitlePermitDef();
                    RoyalTitlePermitDef CallMilitaryAidGrand = new RoyalTitlePermitDef();

                    foreach (RoyalTitlePermitDef b in from permit in DefDatabase<RoyalTitlePermitDef>.AllDefs where true select permit)
                    {
                        RoyalTitlePermitDef newPermit = null;
                        int n = 0;
                        float totalCombatPower = 0f;
                        // 복제
                        switch (b.defName)
                        {
                            case "TradeSettlement":
                                p_TradeSettlement.defName = $"TradeSettlement_{faction}";
                                p_TradeSettlement.label = b.label;
                                break;
                            case "TradeOrbital":
                                p_TradeOrbital.defName = $"TradeOrbital_{faction}";
                                p_TradeOrbital.label = b.label;
                                break;
                            case "TradeCaravan":
                                p_TradeCaravan.defName = $"TradeCaravan_{faction}";
                                p_TradeCaravan.label = b.label;
                                break;

                            case "CallMilitaryAidSmall":
                                newPermit = CallMilitaryAidSmall;
                                n = 0;
                                totalCombatPower = 240f;
                                break;
                            case "CallMilitaryAidLarge":
                                newPermit = CallMilitaryAidLarge;
                                n = 1;
                                totalCombatPower = 400f;
                                break;
                            case "CallMilitaryAidGrand":
                                newPermit = CallMilitaryAidGrand;
                                n = 2;
                                totalCombatPower = 600f;
                                break;
                        }
                        if (newPermit != null)
                        {
                            newPermit.defName = $"{b.defName}_{faction.defName}";
                            newPermit.label = b.label;
                            newPermit.workerClass = b.workerClass;
                            newPermit.cooldownDays = b.cooldownDays;
                            newPermit.royalAid = new RoyalAid();
                            newPermit.royalAid.favorCost = b.royalAid.favorCost;

                            newPermit.royalAid.pawnKindDef = ar_permitPawn[n];

                            newPermit.royalAid.pawnCount = Mathf.RoundToInt(totalCombatPower / ar_permitPawn[n].combatPower);
                        }


                    }

                    DefDatabase<RoyalTitlePermitDef>.Add(p_TradeSettlement);
                    DefDatabase<RoyalTitlePermitDef>.Add(p_TradeOrbital);
                    DefDatabase<RoyalTitlePermitDef>.Add(p_TradeCaravan);

                    DefDatabase<RoyalTitlePermitDef>.Add(CallMilitaryAidSmall);
                    DefDatabase<RoyalTitlePermitDef>.Add(CallMilitaryAidLarge);
                    DefDatabase<RoyalTitlePermitDef>.Add(CallMilitaryAidGrand);


                    if (debugMode) Log.Message("D");



                    // 커스텀 작위
                    List<RoyalTitleDef> ar_titleDef = new List<RoyalTitleDef>();
                    List<RoyalTitleDef> ar_titleDefNoStella = new List<RoyalTitleDef>();
                    List<RoyalTitleDef> ar_titleDefNoEmperor = new List<RoyalTitleDef>();
                    for (int i = 0; i < ar_baseT.Count; i++)
                    {
                        // 복제
                        RoyalTitleDef b = ar_baseT[i];
                        RoyalTitleDef n = new RoyalTitleDef();
                        n.defName = $"{b.defName}_{faction.defName}";
                        n.tags = new List<string>();
                        n.tags.AddRange(faction.royalTitleTags);

                        n.awardThought = b.awardThought;
                        n.bedroomRequirements = b.bedroomRequirements;
                        n.changeHeirQuestPoints = b.changeHeirQuestPoints;
                        n.commonality = b.commonality;
                        n.debugRandomId = b.debugRandomId; // 디버그 랜덤아이디?
                        n.decreeMentalBreakCommonality = b.decreeMentalBreakCommonality;
                        n.decreeMinIntervalDays = b.decreeMinIntervalDays;
                        n.decreeMtbDays = b.decreeMtbDays;
                        n.decreeTags = b.decreeTags;
                        n.description = b.description;
                        n.descriptionHyperlinks = b.descriptionHyperlinks;
                        n.disabledJoyKinds = b.disabledJoyKinds;
                        n.disabledWorkTags = b.disabledWorkTags;
                        n.favorCost = b.favorCost;
                        n.fileName = b.fileName; // 파일명?
                        n.foodRequirement = b.foodRequirement;
                        n.generated = b.generated; // 생성완료?
                        n.ignoreConfigErrors = b.ignoreConfigErrors;
                        n.index = b.index; // 인덱스?
                        n.inheritanceWorkerOverrideClass = b.inheritanceWorkerOverrideClass;
                        n.label = b.label;
                        n.labelFemale = b.labelFemale;
                        n.lostThought = b.lostThought;
                        n.minExpectation = b.minExpectation;
                        n.modContentPack = b.modContentPack;
                        n.modExtensions = b.modExtensions;
                        n.needFallPerDayAuthority = b.needFallPerDayAuthority;
                        if (b.permits != null)
                        {
                            n.permits = new List<RoyalTitlePermitDef>();
                            for (int j = 0; j < b.permits.Count; j++)
                            {
                                RoyalTitlePermitDef newPermit = b.permits[j];

                                switch (newPermit.defName)
                                {
                                    case "TradeSettlement":
                                        newPermit = p_TradeSettlement;
                                        break;
                                    case "TradeOrbital":
                                        newPermit = p_TradeOrbital;
                                        break;
                                    case "TradeCaravan":
                                        newPermit = p_TradeCaravan;
                                        break;

                                    case "CallMilitaryAidSmall":
                                        newPermit = CallMilitaryAidSmall;
                                        break;
                                    case "CallMilitaryAidLarge":
                                        newPermit = CallMilitaryAidLarge;
                                        break;
                                    case "CallMilitaryAidGrand":
                                        newPermit = CallMilitaryAidGrand;
                                        break;
                                }
                                n.permits.Add(newPermit);

                            }
                        }
                        n.recruitmentDifficultyOffset = b.recruitmentDifficultyOffset;
                        n.recruitmentResistanceFactor = b.recruitmentResistanceFactor;
                        n.recruitmentResistanceOffset = b.recruitmentResistanceOffset;
                        n.replaceOnRecruited = b.replaceOnRecruited;
                        if (useApparel != en_apparel.off) // 귀족 의복을 요구할지 작위에 표기
                        {
                            n.requiredApparel = b.requiredApparel;
                        }
                        else
                        {
                            n.requiredApparel = null;
                        }
                        n.requiredMinimumApparelQuality = b.requiredMinimumApparelQuality;
                        n.rewards = b.rewards;
                        n.seniority = b.seniority;
                        n.shortHash = b.shortHash;
                        n.suppressIdleAlert = b.suppressIdleAlert;
                        n.throneRoomRequirements = b.throneRoomRequirements;

                        DefDatabase<RoyalTitleDef>.Add(n);

                        ar_titleDef.Add(n);
                        if (i < ar_baseT.Count - 2) ar_titleDefNoStella.Add(n);
                        if (i < ar_baseT.Count - 1) ar_titleDefNoEmperor.Add(n);
                        

                    }



                    if (debugMode) Log.Message("E");
                    

                    // 귀족 PawnKind 생성


                    // 버그 해결 모드
                    if (allPawn.Count > 0 && bugFixMode)
                    {
                        Log.Message($" - {faction.defName} : make pawnkind with bugFix mode");

                        bool needMakeLeader = (allPawn.Count >= 6 || allPawnLeader.Count > 0);

                        // pawn을 귀족으로 변환

                        for (int i = 0; i < allPawnNoLeader.Count; i++)
                        {

                            PawnKindDef n = allPawn[i];
                            if (needMakeLeader)
                            {
                                n.titleSelectOne = ar_titleDefNoStella;
                            }
                            else
                            {
                                n.titleSelectOne = ar_titleDefNoEmperor;
                            }
                            n.royalTitleChance = 1f;
                            n.allowRoyalApparelRequirements = false; // 복장 요구 여부
                            if (n.techHediffsTags == null)
                            {
                                n.techHediffsTags = new List<string>();
                            }
                            n.techHediffsTags.AddRange(new List<string>() { "Advanced", "ImplantEmpireRoyal", "ImplantEmpireCommon" });

                        }


                        // pawn을 팩션리더 귀족으로 변환

                        if (needMakeLeader)
                        {
                            PawnKindDef n2 = new PawnKindDef();

                            if (allPawnLeader.Count > 0)
                            {
                                n2 = allPawnLeader.RandomElement();
                            }
                            else
                            {
                                n2 = allPawn[allPawn.Count - 1];
                            }

                            n2.titleSelectOne = new List<RoyalTitleDef>();
                            n2.titleRequired = ar_titleDefNoEmperor[ar_titleDefNoEmperor.Count - 1];
                            n2.royalTitleChance = 1f;
                            n2.allowRoyalApparelRequirements = false;
                            if (n2.techHediffsTags == null)
                            {
                                n2.techHediffsTags = new List<string>();
                            }
                            n2.techHediffsTags.AddRange(new List<string>() { "Advanced", "ImplantEmpireRoyal", "ImplantEmpireCommon" });

                        }

                        


                        
                        
                    }


                    // 일반 모드
                    if (allPawn.Count > 0 && !bugFixMode)
                    {
                        Log.Message($" - {faction.defName} : make pawnkind");
                        
                        for (int i = 1; i < ar_titleDef.Count - 1; i++)
                        {
                            

                            RoyalTitleDef t = ar_titleDef[i];
                            PawnKindDef p = allPawnNoLeader[allPawnNoLeader.Count - 1];
                            PawnKindDef n = new PawnKindDef();
                            PawnKindDef titleBasePawn = ar_baseP[i - 1];
                            
                            if(i == ar_titleDef.Count - 2 && allPawnLeader.Count > 0)
                            {
                                p = allPawnLeader.RandomElement(); // stellach 계급은 무조건 리더이어야하므로 리더 값을 베이스로 생성
                            }
                            

                            n.defName = $"royal_{t.defName}_{faction.defName}"; //
                            n.label = titleBasePawn.label; // 라벨
                            n.titleRequired = ar_titleDef[i]; // 정해진 계급

                            n.aiAvoidCover = titleBasePawn.aiAvoidCover;

                            switch (useApparel) // 귀족 폰이 의복을 요구할지 여부
                            {
                                case en_apparel.off:
                                    // 사용안함
                                    n.allowRoyalApparelRequirements = false; // 복장 요구 여부
                                    n.apparelDisallowTags = p.apparelDisallowTags; // 금지 복장
                                    n.apparelTags = p.apparelTags; // 허용복장
                                    n.apparelColor = p.apparelColor;
                                    break;
                                case en_apparel.forced:
                                    // 바닐라
                                    n.allowRoyalApparelRequirements = titleBasePawn.allowRoyalApparelRequirements; // 복장 요구 여부
                                    n.apparelTags = new List<string>() { "IndustrialBasic" };
                                    n.apparelDisallowTags = titleBasePawn.apparelDisallowTags; // 금지 복장
                                    n.specificApparelRequirements = titleBasePawn.specificApparelRequirements; // 귀족 의상 강제
                                    n.apparelColor = titleBasePawn.apparelColor;
                                    break;
                                default:
                                    // 모드아이템
                                    n.allowRoyalApparelRequirements = titleBasePawn.allowRoyalApparelRequirements; // 복장 요구 여부
                                    n.apparelTags = p.apparelTags; // 허용 복장
                                    n.specificApparelRequirements = titleBasePawn.specificApparelRequirements; // 귀족 의상 강제
                                    n.apparelColor = p.apparelColor;
                                    break;
                            }
                            
                            n.allowRoyalRoomRequirements = titleBasePawn.allowRoyalRoomRequirements;

                            n.alternateGraphicChance = p.alternateGraphicChance;
                            n.alternateGraphics = p.alternateGraphics;
                            n.apparelAllowHeadgearChance = titleBasePawn.apparelAllowHeadgearChance; //
                            
                            
                            
                            n.apparelIgnoreSeasons = titleBasePawn.apparelIgnoreSeasons; //
                            n.apparelMoney = titleBasePawn.apparelMoney; // 복장 가격
                            n.apparelRequired = titleBasePawn.apparelRequired; // 복장 강제

                            
                            n.backstoryCategories = p.backstoryCategories;
                            n.backstoryCryptosleepCommonality = p.backstoryCryptosleepCommonality;
                            n.backstoryFilters = p.backstoryFilters;
                            n.backstoryFiltersOverride = p.backstoryFiltersOverride;
                            n.baseRecruitDifficulty = titleBasePawn.baseRecruitDifficulty; //
                            n.biocodeWeaponChance = titleBasePawn.biocodeWeaponChance; //
                            n.canArriveManhunter = p.canArriveManhunter;
                            n.canBeSapper = p.canBeSapper;
                            n.chemicalAddictionChance = p.chemicalAddictionChance;
                            n.combatEnhancingDrugsChance = p.combatEnhancingDrugsChance;
                            n.combatEnhancingDrugsCount = p.combatEnhancingDrugsCount;
                            n.combatPower = p.combatPower;
                            n.debugRandomId = p.debugRandomId;
                            n.defaultFactionType = faction; // 기본 팩션
                            n.defendPointRadius = p.defendPointRadius;
                            
                            n.description = p.description;
                            n.descriptionHyperlinks = p.descriptionHyperlinks;
                            n.destroyGearOnDrop = p.destroyGearOnDrop;

                            if (p.disallowedTraits == null)
                            {
                                n.disallowedTraits = new List<TraitDef>();
                            }
                            else
                            {
                                n.disallowedTraits = p.disallowedTraits.ListFullCopy();
                            }
                            n.disallowedTraits.Add(TraitDefOf.Nudist);
                            n.disallowedTraits.Add(TraitDefOf.Brawler);


                            n.ecoSystemWeight = p.ecoSystemWeight;
                            n.factionLeader = titleBasePawn.factionLeader; // 팩션리더?
                            n.fileName = p.fileName; // 파일명
                            n.fixedInventory = p.fixedInventory;
                            n.fleeHealthThresholdRange = p.fleeHealthThresholdRange;
                            n.forceNormalGearQuality = p.forceNormalGearQuality;
                            n.gearHealthRange = p.gearHealthRange;
                            n.generated = titleBasePawn.generated; // 생성완료?
                            n.hairTags = p.hairTags;
                            n.ignoreConfigErrors = p.ignoreConfigErrors;
                            n.index = titleBasePawn.index; // 인덱스?
                            n.inventoryOptions = titleBasePawn.inventoryOptions;
                            n.invFoodDef = titleBasePawn.invFoodDef;
                            n.invNutrition = titleBasePawn.invNutrition;
                            n.isFighter = titleBasePawn.isFighter;
                            n.itemQuality = titleBasePawn.itemQuality;

                            n.labelFemale = p.labelFemale;
                            n.labelFemalePlural = p.labelFemalePlural;
                            n.labelMale = p.labelMale;
                            n.labelMalePlural = p.labelMalePlural;
                            n.labelPlural = p.labelPlural;
                            n.lifeStages = p.lifeStages;
                            n.maxGenerationAge = p.maxGenerationAge;
                            n.minGenerationAge = p.minGenerationAge;
                            n.modContentPack = p.modContentPack; // 모드?
                            n.modExtensions = p.modExtensions;
                            n.race = p.race; // 종족?
                            n.royalTitleChance = 1f; // 귀족으로 전환할 확률
                            n.shortHash = p.shortHash;
                            n.skills = p.skills;
                            
                            n.techHediffsChance = titleBasePawn.techHediffsChance;




                            if (p.techHediffsDisallowTags == null)
                            {
                                n.techHediffsDisallowTags = new List<string>();
                            }
                            else
                            {
                                n.techHediffsDisallowTags = p.techHediffsDisallowTags.ListFullCopy();
                            }
                            n.techHediffsDisallowTags.Add("PainCauser");


                            n.techHediffsMaxAmount = titleBasePawn.techHediffsMaxAmount;
                            n.techHediffsMoney = titleBasePawn.techHediffsMoney;
                            n.techHediffsRequired = titleBasePawn.techHediffsRequired;



                            if (p.techHediffsTags == null)
                            {
                                n.techHediffsTags = new List<string>();
                            }
                            else
                            {
                                n.techHediffsTags = p.techHediffsTags.ListFullCopy();
                            }
                            n.techHediffsTags.AddRange(new List<string>() { "Advanced", "ImplantEmpireRoyal", "ImplantEmpireCommon" });


                            
                            
                            //for (int i = 0; i < ar_titleDef.Count; i++) // 랜덤 계급
                            //{
                            //    n.titleSelectOne = new List<RoyalTitleDef>();
                            //    n.titleSelectOne.Add(ar_titleDef[i]);
                            //}

                            n.trader = false; // 상인
                            n.weaponMoney = titleBasePawn.weaponMoney;
                            n.weaponTags = p.weaponTags;
                            n.wildGroupSize = titleBasePawn.wildGroupSize;



                            DefDatabase<PawnKindDef>.Add(n);


                        }



                    }


                    // Pawn Kinds 생성 : SpaceRefugee_Clothed
                    if (allPawnNoLeader.Count > 0)
                    {
                        PawnKindDef b0 = PawnKindDef.Named("SpaceRefugee_Clothed");
                        PawnKindDef n0 = copyPawnDef(allPawnNoLeader[0]);
                        n0.defName = $"SpaceRefugee_Clothed_{faction.defName}";
                        n0.apparelMoney = b0.apparelMoney;
                        n0.gearHealthRange = b0.gearHealthRange;
                        if (n0.disallowedTraits == null) n0.disallowedTraits = new List<TraitDef>();
                        n0.disallowedTraits.Add(TraitDefOf.Nudist);
                        n0.baseRecruitDifficulty = b0.baseRecruitDifficulty;
                        n0.forceNormalGearQuality = b0.forceNormalGearQuality;
                        n0.isFighter = b0.isFighter;
                        n0.apparelAllowHeadgearChance = b0.apparelAllowHeadgearChance;
                        n0.techHediffsMoney = b0.techHediffsMoney;
                        n0.techHediffsTags = b0.techHediffsTags;
                        n0.techHediffsChance = b0.techHediffsChance;

                        DefDatabase<PawnKindDef>.Add(n0);
                    }
                    else
                    {
                        PawnKindDef b0 = PawnKindDef.Named("SpaceRefugee_Clothed");
                        PawnKindDef n0 = copyPawnDef(b0);
                        n0.defName = $"SpaceRefugee_Clothed_{faction.defName}";

                        DefDatabase<PawnKindDef>.Add(n0);
                    }
                    






                    if (debugMode) Log.Message("F");

                    // 계급 규칙
                    //faction.royalImplantRules = baseF.royalImplantRules;

                    // 커스텀 계급 규칙
                    List<RoyalImplantRule> ar_rule = new List<RoyalImplantRule>();

                    for (int i = 0; i < baseF.royalImplantRules.Count; i++)
                    {
                        // 복제
                        RoyalImplantRule b = baseF.royalImplantRules[i];
                        RoyalImplantRule n = new RoyalImplantRule();
                        n.implantHediff = b.implantHediff;
                        n.maxLevel = b.maxLevel;
                        n.minTitle = ar_titleDef[i];

                        ar_rule.Add(n);
                    }

                    faction.royalImplantRules = ar_rule;




                    // 계급에 따른 거래제한
                    if (useTradePermit)
                    {
                        

                        RoyalTitlePermitDef p = new RoyalTitlePermitDef();

                        // 기지
                        List<TraderKindDef> ar_t = new List<TraderKindDef>();
                        foreach (TraderKindDef b in faction.baseTraderKinds)
                        {
                            TraderKindDef n = copyTraderDef(b);
                            n.defName = $"{b.defName}_{faction.defName}_base";
                            n.permitRequiredForTrading = p_TradeSettlement;
                            n.faction = faction;
                            DefDatabase<TraderKindDef>.Add(n);
                            ar_t.Add(n);

                        }
                        faction.baseTraderKinds = ar_t;


                        // 캐러밴
                        ar_t = new List<TraderKindDef>();
                        foreach (TraderKindDef b in faction.caravanTraderKinds)
                        {
                            TraderKindDef n = copyTraderDef(b);
                            n.defName = $"{b.defName}_{faction.defName}_caravan";
                            n.permitRequiredForTrading = p_TradeCaravan;
                            n.faction = faction;
                            DefDatabase<TraderKindDef>.Add(n);
                            ar_t.Add(n);

                        }
                        faction.caravanTraderKinds = ar_t;

                        // 궤도상선
                        foreach (TraderKindDef b in from trader in DefDatabase<TraderKindDef>.AllDefs
                                                    where
                                                     trader.orbital && trader.faction != null && trader.faction == faction
                                                    select trader
                                            )
                        {
                            b.permitRequiredForTrading = p_TradeOrbital;
                        }



                    }

                    if (debugMode) Log.Message("G");

                    /*
                    // 세금 징수 캐러밴 상인 생성
                    if (useCollectorTrader)
                    {
                        TraderKindDef n = new TraderKindDef();
                        foreach (TraderKindDef b in from trader in DefDatabase<TraderKindDef>.AllDefs where
                                                    trader.defName == "Empire_Caravan_TributeCollector"
                                                    select trader)
                        {
                            n = copyTraderDef(b);
                            n.defName = $"{faction.defName}_Caravan_TributeCollector";
                            n.commonality = 1f;
                            n.faction = faction;

                        }

                        DefDatabase<TraderKindDef>.Add(n);
                    }
                    */





                    



                }






            }

            /*
            // 바닐라 제국 삭제
            if (delVanilla)
            {
                baseF.hidden = true;
                baseF.royalTitleTags = null;
                baseF.settlementGenerationWeight = 0f;
                baseF.fixedLeaderKinds = null;
                baseF.royalImplantRules = null;
                baseF.royalTitleInheritanceRelations = null;
                baseF.royalTitleInheritanceWorkerClass = null;
                baseF.minTitleForBladelinkWeapons = null;
                baseF.pawnGroupMakers = null;
                foreach (TraderKindDef t in from trader in DefDatabase<TraderKindDef>.AllDefs
                                            where
                                             trader.faction == baseF
                                            select trader)
                {
                    t.faction = null;
                }

            }
            */












        }









        public static void patchRelation()
        {
            for (int z = 0; z < ar_faction.Count; z++)
            {
                FactionDef faction = ar_faction[z];


                // 관계
                switch (ar_faction_relation[z])
                {
                    case en_relation.basic:
                        break;
                    case en_relation.empire:
                        faction.permanentEnemy = false;
                        faction.mustStartOneEnemy = false;
                        faction.startingGoodwill = IntRange.FromString("0");
                        faction.naturalColonyGoodwill = IntRange.FromString("0~0");
                        faction.goodwillDailyGain = 0f;
                        faction.goodwillDailyFall = 0f;
                        break;
                    case en_relation.ally:
                        faction.permanentEnemy = false;
                        faction.mustStartOneEnemy = false;
                        faction.startingGoodwill = IntRange.FromString("80");
                        faction.naturalColonyGoodwill = IntRange.FromString("-50~50");
                        faction.goodwillDailyGain = 0.2f;
                        faction.goodwillDailyFall = 0.2f;
                        break;
                    case en_relation.neutral:
                        faction.permanentEnemy = false;
                        faction.mustStartOneEnemy = false;
                        faction.startingGoodwill = IntRange.FromString("0");
                        faction.naturalColonyGoodwill = IntRange.FromString("-50~50");
                        faction.goodwillDailyGain = 0.2f;
                        faction.goodwillDailyFall = 0.2f;
                        break;
                    case en_relation.enemy:
                        faction.permanentEnemy = false;
                        faction.mustStartOneEnemy = false;
                        faction.startingGoodwill = IntRange.FromString("-80");
                        faction.naturalColonyGoodwill = IntRange.FromString("-100~-80");
                        faction.goodwillDailyGain = 0.2f;
                        faction.goodwillDailyFall = 0.2f;
                        break;
                    case en_relation.permanentEnemy:
                        faction.permanentEnemy = true;
                        break;
                }


                if (ar_faction_toEmpire[z] != en_make.no)
                {
                    // 적대 세력일 경우
                    if (faction.permanentEnemy)
                    {
                        faction.permanentEnemy = false;
                        faction.mustStartOneEnemy = false;

                        faction.startingGoodwill = IntRange.FromString("-80");
                        faction.naturalColonyGoodwill = IntRange.FromString("-100~-80");
                        faction.goodwillDailyGain = 0.2f;
                        faction.goodwillDailyFall = 0.2f;
                    }
                }
            }
        }




        public static PawnKindDef copyPawnDef(PawnKindDef b)
        {
            PawnKindDef n = new PawnKindDef();
            
            n.defName = b.defName;
            n.label = b.label;
            n.aiAvoidCover = b.aiAvoidCover;
            n.allowRoyalApparelRequirements = b.allowRoyalApparelRequirements;
            n.allowRoyalRoomRequirements = b.allowRoyalRoomRequirements;
            n.alternateGraphicChance = b.alternateGraphicChance;
            n.alternateGraphics = b.alternateGraphics;
            n.apparelAllowHeadgearChance = b.apparelAllowHeadgearChance; //
            n.apparelColor = b.apparelColor;
            n.apparelDisallowTags = b.apparelDisallowTags;
            n.apparelIgnoreSeasons = b.apparelIgnoreSeasons;
            n.apparelMoney = b.apparelMoney;
            n.apparelRequired = b.apparelRequired;
            n.apparelTags = b.apparelTags;
            n.backstoryCategories = b.backstoryCategories;
            n.backstoryCryptosleepCommonality = b.backstoryCryptosleepCommonality;
            n.backstoryFilters = b.backstoryFilters;
            n.backstoryFiltersOverride = b.backstoryFiltersOverride;
            n.baseRecruitDifficulty = b.baseRecruitDifficulty; //
            n.biocodeWeaponChance = b.biocodeWeaponChance; //
            n.canArriveManhunter = b.canArriveManhunter;
            n.canBeSapper = b.canBeSapper;
            n.chemicalAddictionChance = b.chemicalAddictionChance;
            n.combatEnhancingDrugsChance = b.combatEnhancingDrugsChance;
            n.combatEnhancingDrugsCount = b.combatEnhancingDrugsCount;
            n.combatPower = b.combatPower;
            n.debugRandomId = b.debugRandomId;
            n.defaultFactionType = b.defaultFactionType;
            n.defendPointRadius = b.defendPointRadius;
            n.description = b.description;
            n.descriptionHyperlinks = b.descriptionHyperlinks;
            n.destroyGearOnDrop = b.destroyGearOnDrop;
            n.disallowedTraits = b.disallowedTraits;
            n.ecoSystemWeight = b.ecoSystemWeight;
            n.factionLeader = b.factionLeader; // 팩션리더?
            n.fileName = b.fileName;
            n.fixedInventory = b.fixedInventory;
            n.fleeHealthThresholdRange = b.fleeHealthThresholdRange;
            n.forceNormalGearQuality = b.forceNormalGearQuality;
            n.gearHealthRange = b.gearHealthRange;
            n.generated = b.generated; // 생성완료?
            n.hairTags = b.hairTags;
            n.ignoreConfigErrors = b.ignoreConfigErrors;
            n.index = b.index; // 인덱스?
            n.inventoryOptions = b.inventoryOptions;
            n.invFoodDef = b.invFoodDef;
            n.invNutrition = b.invNutrition;
            n.isFighter = b.isFighter;
            n.itemQuality = b.itemQuality;
            n.labelFemale = b.labelFemale;
            n.labelFemalePlural = b.labelFemalePlural;
            n.labelMale = b.labelMale;
            n.labelMalePlural = b.labelMalePlural;
            n.labelPlural = b.labelPlural;
            n.lifeStages = b.lifeStages;
            n.maxGenerationAge = b.maxGenerationAge;
            n.minGenerationAge = b.minGenerationAge;
            n.modContentPack = b.modContentPack; // 모드?
            n.modExtensions = b.modExtensions;
            n.race = b.race; // 종족?
            n.royalTitleChance = 1f;
            n.shortHash = b.shortHash;
            n.skills = b.skills;
            n.specificApparelRequirements = b.specificApparelRequirements; // 귀족 의상
            n.techHediffsChance = b.techHediffsChance;
            n.techHediffsDisallowTags = b.techHediffsDisallowTags;
            n.techHediffsMaxAmount = b.techHediffsMaxAmount;
            n.techHediffsMoney = b.techHediffsMoney;
            n.techHediffsRequired = b.techHediffsRequired;
            n.techHediffsTags = b.techHediffsTags;
            n.titleRequired = b.titleRequired; // 정해진 계급
            n.trader = b.trader;
            n.weaponMoney = b.weaponMoney;
            n.weaponTags = b.weaponTags;
            n.wildGroupSize = b.wildGroupSize;

            return n;
        }

        public static TraderKindDef copyTraderDef(TraderKindDef b)
        {
            TraderKindDef n = new TraderKindDef();
            n.defName = b.defName;
            n.permitRequiredForTrading = b.permitRequiredForTrading;
            n.faction = b.faction;
            n.category = b.category;
            n.commonality = b.commonality;
            n.commonalityMultFromPopulationIntent = b.commonalityMultFromPopulationIntent;
            n.description = b.description;
            n.descriptionHyperlinks = b.descriptionHyperlinks;
            n.hideThingsNotWillingToTrade = b.hideThingsNotWillingToTrade;
            n.ignoreConfigErrors = b.ignoreConfigErrors;
            n.label = b.label;
            n.modContentPack = b.modContentPack;
            n.modExtensions = b.modExtensions;
            n.orbital = b.orbital;
            n.requestable = b.requestable;
            n.shortHash = b.shortHash;
            n.stockGenerators = b.stockGenerators;
            n.tradeCurrency = b.tradeCurrency;

            return n;
        }


        public static bool IsViolatingRulesOf(Def implantOrWeapon, Pawn pawn, Faction faction, int implantLevel = 0)
        {
            if (faction.def.royalImplantRules == null || faction.def.royalImplantRules.Count == 0)
            {
                return true;
            }
            RoyalTitleDef minTitleToUse = ThingRequiringRoyalPermissionUtility.GetMinTitleToUse(implantOrWeapon, faction, implantLevel);
            RoyalTitleDef currentTitle = pawn.royalty.GetCurrentTitle(faction);
            if (currentTitle == null)
            {
                return true;
            }
            int num = faction.def.RoyalTitlesAwardableInSeniorityOrderForReading.IndexOf(currentTitle);
            if (num < 0)
            {
                return true;
            }
            int num2 = faction.def.RoyalTitlesAwardableInSeniorityOrderForReading.IndexOf(minTitleToUse);
            return num < num2;
        }


    }

}
